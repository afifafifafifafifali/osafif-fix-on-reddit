#include "console_input.h"

#include <stdint.h>
#include <stdbool.h>

#include "print.h"
#include "port.h"

char characterTable[] = {
    0,    0,    '1',  '2',  '3',  '4',  '5',  '6',  '7',  '8',  '9',  '0',
    '-',  '=',  0,    0x09, 'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',
    'o',  'p',  '[',  ']',  0,    0,    'a',  's',  'd',  'f',  'g',  'h',
    'j',  'k',  'l',  ';',  '\'', '`',  0,    '\\', 'z',  'x',  'c',  'v',
    'b',  'n',  'm',  ',',  '.',  '/',  0,    '*',  0x0F, ' ',  0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0x1B, 0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0x0E, 0x1C, 0,    0,    0,
    0,    0,    0,    0,    0,    '/',  0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0,
    0,    0,    0,    0,    0,    0,    0,    0x2C,
};

char shiftedCharacterTable[] = {
    0,    0,    '!',  '@',  '#',  '$',  '%',  '^',  '&',  '*',  '(',  ')',
    '_',  '+',  0,    0x09, 'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
    'O',  'P',  '{',  '}',  0,    0,    'A',  'S',  'D',  'F',  'G',  'H',
    'J',  'K',  'L',  ':',  '"',  '~',  0,    '|',  'Z',  'X',  'C',  'V',
    'B',  'N',  'M',  '<',  '>',  '?',  0,    '*',  0x0F, ' ',  0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0x1B, 0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0x0E, 0x1C, 0,    0,    0,
    0,    0,    0,    0,    0,    '?',  0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0,
    0,    0,    0,    0,    0,    0,    0,    0x2C,
};

typedef uint8_t uint8;

string readStr(string buffstr) {
    // char buff;
    // string buffstr = (string)malloc(200);
    uint8 i = 0;
    uint8 reading = 1;
    int   shifted = 0;
    int   capsLocked = 0;
  
    while (reading) {
      if (inb(0x64) & 0x1) {
        uint8 scanCode = inb(0x60);
  
        // Shift checks
        if (shifted == 1 && scanCode & 0x80) {
          if ((scanCode & 0x7F) == 42) // & 0x7F clears the release
            shifted = 0;
        }
  
        if (scanCode < sizeof(characterTable) && !(scanCode & 0x80)) {
          char character = (shifted || capsLocked)
                               ? shiftedCharacterTable[scanCode]
                               : characterTable[scanCode];
  
          if (character != 0) { // Normal char
            print_char(character);
            buffstr[i] = character;
            i++;
          } else if (scanCode == 28) // Enter
          {
            buffstr[i] = '\0';
            reading = 0;
          } else if (scanCode == 14) // Backspace
          {
            if (i > 0) {
              print_char('\b');
              i--;
              buffstr[i + 1] = 0;
              buffstr[i] = 0;
            }
          } else if (scanCode == 42) { // Shift
            shifted = 1;
          } else if (scanCode == 58) { // Caps lock
            capsLocked = !capsLocked;
          }
        }
      }
    }
    // buffstr[i - 1] = 0;
    return buffstr;
  }

