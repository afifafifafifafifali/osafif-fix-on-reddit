#pragma once

// Keyboard drivaer(For this ose's dos version only)

#include <stdint.h>
#include <stdbool.h>


typedef char* string;

string readStr(string buffstr);